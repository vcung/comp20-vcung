// Express initialization
var express = require('express');
var app = express.createServer(express.logger());//var app = express(express.logger());
app.use(express.bodyParser());
app.set('title', 'nodeapp');

// Mongo initialization
var mongoUri = 'mongodb://frogger:highscore@widmore.mongohq.com:10000/scorecenter';
var mongo = require('mongodb');
var db = mongo.Db.connect(mongoUri, function (error, databaseConnection) {
    db = databaseConnection;
});
//enable cross-domain scripting
app.all('/', function(req, res, next) {
   res.header("Access-Control-Allow-Origin", "*");
   res.header("Access-Control-Allow-Headers", "X-Requested-With");
   res.header('Access-Control-Allow-Methods', "*");
   res.header('Access-Control-Allow-Headers', 'Content-Type');
   next();
});

//index page
app.get('/', function(request, response) {
    db.collection('scores', function(err, collection) {
        collection.find().toArray(function(err, results) {
            var html = "<html><h1>All Scores</h1><body><table><tr><th>Created at</th><th>Game Title</th><th>Username</th><th>Score</th></tr>";
            for (x in results) {
                html += '<tr><td>'+results[x].created_at + "</td><td>" + results[x].game_title + "</td><td>" + results[x].username + "</td><td>" + results[x].score + "</td></tr>";
            }       
            html += "</table></body></html>";
            response.send(html);
        });
    });
});

//GET API
//returns a JSON string of top 10 scores associated with give game title
app.get('/highscores.json', function(request, response) {
    //the json string
    var json;
    var q = request.query;
    db.collection("scores", function(err, collection) {
        collection.find({game_title: q.game_title}, {'sort':{score: -1}, 'limit':10}).toArray( function (er, results) {
			if (er) {
				reponse.send('error in highscores');
			} else {
				response.send(JSON.stringify(results));
			}
        });
    });
});

//POST API
//takes in a game_title, username, and score and adds them to the database
//fields cannot be null
app.post('/submit.json', function(request, response) {
    var q = request.query;
    var date = new Date();
    if ((q.game_title === 'null') || (q.username === 'null') || (q.score === 'null')) {
        response.send('Error: Some fields are null');
    } else {    
        db.collection('scores', function(er, collection) {
            if (!collection) {
                response.send('No results found');
            } else {
                collection.insert({game_title: q.game_title, username: q.username, score: parseInt(q.score), created_at: date}, function(er, submission) {
                    if (er) {
                        response.send('<p>error in submit<p>');
                    } else {
                        response.send(submission);
                    } 
                });
            }
        });
    }
});

//takes in a username and returns the high scores of all games for that user
app.get('/founduser', function(request, response) {
    var q = request.query;
	var pageHTML = '<body><h1>High Scores for ' + q.username + '</h1><table><tr><th>Game</th><th>High Score</th></tr>';
    var prevTitle = ' ';
	var i;
    db.collection("scores", function(err, collection) {
        collection.find({username: q.username}, {'sort':{game_title: 1, score: -1}}).toArray( function (er, results) {
			if (er||(!results)) {
				reponse.send('No results');
			} else {
				for (i in results) {
					if (results[i].game_title !== prevTitle) { //only records the first score for that game title
						prevTitle = results[i].game_title;
						pageHTML += '<tr><td>' + results[i].game_title + '</td><td>' + results[i].score +'</td></tr>';
					}
				}
				pageHTML += '</table></body>';
				response.send(pageHTML);				
			}
        });
    });
});

//search for user
app.get('/usersearch', function(request, response) {
    //redirects page on click of submit button
    var pageHTML = '<body><h1>Search for user</h1><form action = "http://dry-badlands-8229.herokuapp.com/founduser" method ="get">';
    //input box
    pageHTML += '<input type="text" id="input" placeholder="Type in a username" name="username" size="30" /><input type="submit" id="submit" name="submitBtn" value = "Submit" />';
    //closing tags
    pageHTML += '</form></body>';
    response.send(pageHTML);
});
    
var port = process.env.PORT || 5000;
app.listen(port, function() {
  console.log("Listening on " + port);
});